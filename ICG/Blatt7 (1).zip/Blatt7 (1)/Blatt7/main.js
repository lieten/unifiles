let gl;
let program;
let meshes = [];
let lastTimestamp = 0.0;
let viewMatrix = glMatrix.mat4.create();
let viewMatrixLoc;
let projectionMatrix = glMatrix.mat4.create();
let modelViewProjection = glMatrix.mat4.create();
let modelMatrix;
let kaLoc, kdLoc, ksLoc, nloc;
let iaLoc, idLoc, isLoc;
let eyeLoc, lightLoc;
let Ia = [0.3, 0.3, 0.3, 1.0];
let Id = [0.8, 0.8, 0.8, 1.0];
let Is = [0.7, 0.7, 0.7, 1.0];
let light = glMatrix.vec4.fromValues(1.0, 4.0, 0.0, 1.0);
let target, eye, up;

class Mesh {
	constructor (positions, colors, indices, normals) {
		this.positions = positions;
		this.colors = colors;
		this.indices = indices;
		this.initalized = false;
		this.modelMatrix = glMatrix.mat4.create();
		this.normals = normals
	}
	
	intialize() {
		this.initalized = true;
		
		// Create VBO for positions and activate it
		this.posVBO = gl.createBuffer();
		gl.bindBuffer(gl.ARRAY_BUFFER, this.posVBO);
		
		// Fill VBO with positions
		gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(this.positions), gl.STATIC_DRAW);
		
		// Create VBO for colors and activate it
		this.colorVBO = gl.createBuffer();
		gl.bindBuffer(gl.ARRAY_BUFFER, this.colorVBO);
		
		// Fill VBO with colors
		gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(this.colors), gl.STATIC_DRAW);
		
		// Create VBO for indices and activate it
		this.indexVBO = gl.createBuffer();
		gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.indexVBO);
		
		// Fill VBO with indices
		gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint32Array(this.indices), gl.STATIC_DRAW);

		//Create VBO for normals and activate it
		this.normalVBO = gl.createBuffer()
		gl.bindBuffer(gl.ARRAY_BUFFER, this.normalVBO);

		//Fill VBO with indices
		gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(this.normals), gl.STATIC_DRAW)
	}
	
	update() {
		// Aktualisiere die Variablen der Vertex und Fragment Shader
		gl.uniformMatrix4fv(modelMatrix, false, this.modelMatrix)
		gl.uniform4fv(kaLoc, this.kvalues[0])
		gl.uniform4fv(kdLoc, this.kvalues[1])
		gl.uniform4fv(ksLoc, this.kvalues[2])
		gl.uniform1f(nloc, this.kvalues[3])
		gl.uniform4fv(iaLoc, Ia)
		gl.uniform4fv(idLoc, Id)
		gl.uniform4fv(isLoc, Is)
		let eyeVec4 = glMatrix.vec4.fromValues(eye[0], eye[1], eye[2], 0.0)
		gl.uniform4fv(eyeLoc, eyeVec4)
		gl.uniform4fv(lightLoc, light)
	}

	setModelMatrix(mat) {
		this.modelMatrix = mat;
	}

	setKvalues(kvalues) {
		this.kvalues = kvalues
	}

	render() {
		if (!this.initalized) {
			this.intialize();
		}

		// Link data in VBO to shader variables
		gl.bindBuffer(gl.ARRAY_BUFFER, this.posVBO);
		const posLoc = gl.getAttribLocation(program, "vPosition");
		gl.enableVertexAttribArray(posLoc);
		// 2. Change number of components per position to 3
		gl.vertexAttribPointer(posLoc, 3, gl.FLOAT, false, 0, 0);

		// Link data in VBO to shader variables
		gl.bindBuffer(gl.ARRAY_BUFFER, this.colorVBO);
		const colorLoc = gl.getAttribLocation(program, "vColor");
		
		gl.enableVertexAttribArray(colorLoc);
		gl.vertexAttribPointer(colorLoc, 4, gl.FLOAT, false, 0, 0);

		// Link data in VBO to shader variables
		gl.bindBuffer(gl.ARRAY_BUFFER, this.normalVBO);
		const normalLoc = gl.getAttribLocation(program, "vNormal");
		//console.log(normalLoc)
		gl.enableVertexAttribArray(normalLoc);
		gl.vertexAttribPointer(normalLoc, 3, gl.FLOAT, false, 0, 0); 
		// Bind data in index VBO
		gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.indexVBO);

		// 4. Match number of vertices to size of new positions array
		gl.drawElements(gl.TRIANGLES, this.indices.length, gl.UNSIGNED_INT, 0);
	}
}

function meshConverter(model) {
	// 1. Get positions from the cube
	let positions = model.meshes[0].vertices;

	// 2. Generate colors for the cube
	let colors;
	if (model.meshes[0].colors) {
		// if the mesh supports colors
		colors = model.meshes[0].colors.flat()
	} else {
		// if not we set one
		colors = model.meshes[0].vertices.map(x => [1, 0.2, 0.5, 1]).flat()
	}
	// 3. Get indices from the cube and flatten them
	let indices = model.meshes[0].faces.flat();

	let normals = model.meshes[0].normals
	return new Mesh(positions, colors, indices, normals);
}

//Bewegung der Kamera mit WASD
function move(e) 
{
	switch(e.key.toLowerCase()) {
		case 'w':
			target[2] -= 1.0
			eye[2] -= 1.0
			break
		case 'a':
			target[0] -= 1
			eye[0] -= 1
			break
		case 's':
			target[2] += 1
			eye[2] += 1
			break
		case 'd':
			target[0] += 1
			eye[0] += 1
			break
	}
	glMatrix.mat4.lookAt(viewMatrix, eye, target, up)
	gl.uniformMatrix4fv(viewMatrixLoc, false, viewMatrix)
}

//Schwenken der Kamera mit Maus
const speed = 0.01
function changeView(e) 
{
	glMatrix.vec3.rotateY(target, target, eye, -e.movementX * speed)
	glMatrix.vec3.rotateX(target, target, eye, -e.movementY * speed)
	glMatrix.mat4.lookAt(viewMatrix, eye, target, up)
	gl.uniformMatrix4fv(viewMatrixLoc, false, viewMatrix)
}

async function main() {

	// Get canvas and setup WebGL context
    const canvas = document.getElementById("gl-canvas");
	gl = canvas.getContext('webgl2');

	// Configure viewport
	gl.viewport(0,0,canvas.width,canvas.height);
	gl.clearColor(1.0,1.0,1.0,1.0);

	// 5. Add depth test
	gl.enable(gl.DEPTH_TEST);

	// Init shader program via additional function and bind it
	program = await initShaders(gl, "shaders/simple.vert.glsl", "shaders/simple.frag.glsl");
	gl.useProgram(program);

	// Bestimme Locations der Shadervariablen für Model und View Matrix
	viewMatrixLoc = gl.getUniformLocation(program, "viewMatrix")
	modelMatrix = gl.getUniformLocation(program, "modelMatrix")
	// Bestimme Location fuer k-variablen
	kaLoc = gl.getUniformLocation(program, "ka")
	kdLoc = gl.getUniformLocation(program, "kd")
	ksLoc = gl.getUniformLocation(program, "ks")
	nloc = gl.getUniformLocation(program, "nexp")
	iaLoc = gl.getUniformLocation(program, "Ia")
	idLoc = gl.getUniformLocation(program, "Id")
	isLoc = gl.getUniformLocation(program, "Is")
	eyeLoc = gl.getUniformLocation(program,"eye")
	lightLoc = gl.getUniformLocation(program, "light")
	
	//Viewmatrix erstellen
	eye = glMatrix.vec3.fromValues(0.0, 2.0, 15.0)
	target = glMatrix.vec3.fromValues(0.0, 0.3, 0.0)
	up = glMatrix.vec3.fromValues(0.0, 1.0, 0.0)
	
	glMatrix.mat4.lookAt(viewMatrix, eye, target, up);
	
	//Übergebe die initiale View Matrix an den Shader
	gl.uniformMatrix4fv(viewMatrixLoc, false, viewMatrix)
	//Füge einen Event Listener für Tastatureingaben hinzu
	document.addEventListener('mousemove', changeView)
	document.addEventListener('keypress', move)

	let files = [
		"meshes/island.ply",
		"meshes/baum.ply",
		"meshes/wolke.ply",
		"meshes/baum.ply",
		"meshes/wolke.ply",
	];

	let matrices = [
		glMatrix.mat4.create(),
		glMatrix.mat4.create(),
		glMatrix.mat4.create(),
		glMatrix.mat4.create(),
		glMatrix.mat4.create(),
	];
	// Indexreihenfolge: 0=ka, 1=kd, 2=ks, 3=n
	kinsel = [[0.4, 0.7, 0.0, 1.0],
		[0.6, 0.7, 0.0, 1.0], 
		[0.7, 0.7, 0.7, 1.0],
		1.0]

	kbaum =  [[0.2, 0.5, 0.0, 1.0],
		[0.4, 0.8, 0.2, 1.0],
		[0.6, 0.9, 0.2, 1.0],
		1.0]
			  
	kwolke = [[0.9, 0.9, 0.9, 1.0],
		[0.9, 0.9, 0.9, 1.0], 
		[1.0, 1.0, 1.0, 1.0],
		1.0]

	let kvalues = [
		kinsel,
		kbaum,
		kwolke,
		kbaum,
		kwolke
	]

	let baum2 = matrices[1];
	glMatrix.mat4.translate(baum2, baum2, [1, 0, 1])
	glMatrix.mat4.scale(baum2, baum2, [0.5, 0.5, 0.5])
	let wolke2 = matrices[2];
	glMatrix.mat4.translate(wolke2, wolke2, [2, 0, 2])

	for (let i = 0; i < files.length; i++) {
		let mesh = await readMeshAsync(files[i], meshConverter);
		mesh.setModelMatrix(matrices[i]);
		mesh.setKvalues(kvalues[i])
		meshes.push(mesh);
	}

	window.requestAnimationFrame(render);
};

function render(timestamp) {
	const elapsed = timestamp - lastTimestamp;
	gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
	for (let i = 0; i < meshes.length; ++i) {
		meshes[i].update()
		meshes[i].render();
	}
	lastTimestamp = timestamp;
	window.requestAnimationFrame(render);
}

window.onload = async function () {
	main();
};

